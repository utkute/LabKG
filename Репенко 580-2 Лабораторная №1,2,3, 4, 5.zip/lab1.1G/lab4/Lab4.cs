﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab1._1G
{
    public partial class Lab4 : Form
    {
        double[,] kv = new double[4, 3];
        double[,] osi = new double[4, 3];
        double[,] v18 = new double[4, 3];
        double[,] matr_sdv = new double[3, 3];
        double[,] matr_pov = new double[3, 3];
        int k, l, kp,lp;
        bool f = true;
        bool isKv = false;
        bool isV18 = false;

        private void Init_kvadrat()
        {
            kv[0, 0] = -50; kv[0, 1] = 0; kv[0, 2] = 1;
            kv[1, 0] = 0; kv[1, 1] = 50; kv[1, 2] = 1;
            kv[2, 0] = 50; kv[2, 1] = 0; kv[2, 2] = 1;
            kv[3, 0] = 0; kv[3, 1] = -50; kv[3, 2] = 1;
        }

        private void Init_V18()
        {
            v18[0, 0] = 50; v18[0, 1] = -70; v18[0, 2] = 1;
            v18[1, 0] = 0; v18[1, 1] = -50; v18[1, 2] = 1;
            v18[2, 0] = -50; v18[2, 1] = -70; v18[2, 2] = 1;
            v18[3, 0] = 0; v18[3, 1] = 105; v18[3, 2] = 1;
        }
        private void Init_matr_preob(int k1, int l1)
        {
            matr_sdv[0, 0] = 1; matr_sdv[0, 1] = 0; matr_sdv[0, 2] = 0;
            matr_sdv[1, 0] = 0; matr_sdv[1, 1] = 1; matr_sdv[1, 2] = 0;
            matr_sdv[2, 0] = k1; matr_sdv[2, 1] = l1; matr_sdv[2, 2] = 1;
        }
        private void Init_osi()
        {
            osi[0, 0] = -200; osi[0, 1] = 0; osi[0, 2] = 1;
            osi[1, 0] = 200; osi[1, 1] = 0; osi[1, 2] = 1;
            osi[2, 0] = 0; osi[2, 1] = 200; osi[2, 2] = 1;
            osi[3, 0] = 0; osi[3, 1] = -200; osi[3, 2] = 1;
        }
        private void Init_Matr_Povorot()
        {
            matr_pov[0, 0] =Math.Cos(Math.PI/3) ; matr_pov[0, 1] = Math.Sin(Math.PI/3); matr_pov[0, 2] = 0;
            matr_pov[1, 0] = -Math.Sin(Math.PI/3); matr_pov[1, 1] = Math.Cos(Math.PI/3); matr_pov[1, 2] = 0;
            matr_pov[2, 0] =0 ; matr_pov[2, 1] = 0; matr_pov[2, 2] = 1;
        }

        private double[,] Multiply_matr(double[,] a, double[,] b)
        {
            int n = a.GetLength(0);
            int m = a.GetLength(1);

            double[,] r = new double[n, m];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    r[i, j] = 0;
                    for (int ii = 0; ii < m; ii++)
                    {
                        r[i, j] += a[i, ii] * b[ii, j];
                    }
                }
            }
            return r;
        }

        private void Draw_V18_Povorot(Color curentColor, int k, int l)
        {
            v18 = Multiply_matr(v18, matr_pov);
            Init_matr_preob(k, l);
            double[,] v18_1 = Multiply_matr(v18, matr_sdv);
            DravFigure(curentColor, v18_1);
        }

        private void Draw_V18(Color curentColor, int k, int l)
        {
            isV18 = true;
            
            Init_matr_preob(k, l);
            double[,] v18_1 = Multiply_matr(v18, matr_sdv);
            DravFigure(curentColor, v18_1);
        }

        private void Draw_Kv(Color curentColor, int k, int l)
        {
            isKv = true;
            Init_matr_preob(k, l);
            double[,] kv1 = Multiply_matr(kv, matr_sdv);
            DravFigure(curentColor, kv1);
        }
        private void DravFigure(Color curentColor, double [ , ] matr)
        {
            Pen myPen = new Pen(curentColor, 2);
            Graphics g = Graphics.FromHwnd(pictureBox1.Handle);
            // рисуем 1 сторону квадрата
            g.DrawLine(myPen, (int)matr[0, 0], (int)matr[0, 1], (int)matr[1, 0], (int)matr[1, 1]);
            // рисуем 2 сторону квадрата
            g.DrawLine(myPen, (int)matr[1, 0], (int)matr[1, 1], (int)matr[2, 0], (int)matr[2, 1]);
            // рисуем 3 сторону квадрата
            g.DrawLine(myPen, (int)matr[2, 0], (int)matr[2, 1], (int)matr[3, 0], (int)matr[3, 1]);
            // рисуем 4 сторону квадрата
            g.DrawLine(myPen, (int)matr[3, 0], (int)matr[3, 1], (int)matr[0, 0], (int)matr[0, 1]);
            g.Dispose();
            myPen.Dispose();
        }

        private void Draw_osi(int k, int l)
        {
         
            Init_osi();
            Init_matr_preob(k, l);
            double[,] osi1 = Multiply_matr(osi, matr_sdv);
            Pen myPen = new Pen(Color.Red, 1);// цвет линии и ширина
            Graphics g = Graphics.FromHwnd(pictureBox1.Handle);
            // рисуем ось ОХ
            g.DrawLine(myPen, (int)osi1[0, 0], (int)osi1[0, 1], (int)osi1[1, 0], (int)osi1[1,
            1]);
            // рисуем ось ОУ
            g.DrawLine(myPen, (int)osi1[2, 0], (int)osi1[2, 1], (int)osi1[3, 0], (int)osi1[3,1]);
            g.Dispose();
            myPen.Dispose();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Init_kvadrat();
            Init_V18();
            
            if (radioButton5.Checked == true)
            {
                Draw_Kv(Color.Blue, k ,l);
            }
            else if (radioButton6.Checked == true)
            {
                Draw_V18(Color.Blue, k, l);
            }
            else
            {
                MessageBox.Show("Вы не выбрали фигуру");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Draw_osi(pictureBox1.Width / 2,
            pictureBox1.Height / 2);
        }

        private void ChooseFigureSdv(int direction,ref int xOrY)
        {
            if (radioButton5.Checked == true)
            {
                Draw_Kv(pictureBox1.BackColor, k, l);
                Draw_osi(pictureBox1.Width / 2,
               pictureBox1.Height / 2);
                if(isV18)
                {
                    Draw_V18(Color.Blue, kp, lp);
                }
                xOrY += direction;
                Draw_Kv(Color.Blue, k, l);
            }
            if(radioButton6.Checked == true)
            {
                Draw_V18(pictureBox1.BackColor, k, l);
                Draw_osi(pictureBox1.Width / 2,
               pictureBox1.Height / 2);
                if (isKv) 
                {
                    Draw_Kv(Color.Blue, kp, lp);
                }
                xOrY += direction;
                Draw_V18(Color.Blue, k, l);
            }    
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChooseFigureSdv(5, ref k);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true ||
                radioButton2.Checked == true ||
                radioButton3.Checked == true ||
                radioButton4.Checked == true)
            {
                timer1.Interval = 100;
                button8.Text = "Стоп";
                if (f == true)
                {
                    timer1.Start();
                }
                else
                {
                    timer1.Stop();
                    button8.Text = "Старт";
                }
                f = !f;
            }
            else
            {
                MessageBox.Show("Вы не выбрали направление сдвига");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                ChooseFigureSdv(1, ref k);
            }
            else if (radioButton2.Checked == true)
            {
                ChooseFigureSdv(-1, ref k);
            }
            else if (radioButton3.Checked == true)
            {
                ChooseFigureSdv(1, ref l);
            }
            else if (radioButton4.Checked == true)
            {
                ChooseFigureSdv(-1, ref l);
            } 
            Thread.Sleep(100);  
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ChooseFigureSdv(-5, ref k);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ChooseFigureSdv(5, ref l);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ChooseFigureSdv(-5, ref l);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (radioButton6.Checked == true)
            {
                Draw_V18(pictureBox1.BackColor, k, l);
                Draw_osi(pictureBox1.Width / 2,
                   pictureBox1.Height / 2);
                Draw_V18_Povorot(Color.Blue, k, l);
            }
        }

        private void Lab4_Load(object sender, EventArgs e)
        {
            kp = pictureBox1.Width / 2;
            lp = pictureBox1.Height / 2;
            k = pictureBox1.Width / 2;
            l = pictureBox1.Height / 2;
            Init_Matr_Povorot();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            int swap = l;
            l = lp;
            lp = swap;
            swap = kp;
            kp = k;
            k = swap;
            
        }

        public Lab4()
        {
            InitializeComponent();
        }
    }
}
